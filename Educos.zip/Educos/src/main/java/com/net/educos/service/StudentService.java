package com.net.educos.service;

import java.util.List;

import com.net.educos.model.Student;

public interface StudentService 
{
public void addStudent(Student student);
public List<Student> getStudents();
}
