package com.net.educos.model;

public class Student 
{
private int sid;
private String sname;
private String stream;
private String sgender;
private String saddress;
private String scontact;
private String semail;
private String spassword;
private String srepassword;
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getStream() {
	return stream;
}
public void setStream(String stream) {
	this.stream = stream;
}
public String getSgender() {
	return sgender;
}
public void setSgender(String sgender) {
	this.sgender = sgender;
}
public String getSaddress() {
	return saddress;
}
public void setSaddress(String saddress) {
	this.saddress = saddress;
}
public String getScontact() {
	return scontact;
}
public void setScontact(String scontact) {
	this.scontact = scontact;
}
public String getSemail() {
	return semail;
}
public void setSemail(String semail) {
	this.semail = semail;
}
public String getSpassword() {
	return spassword;
}
public void setSpassword(String spassword) {
	this.spassword = spassword;
}
public String getSrepassword() {
	return srepassword;
}
public void setSrepassword(String srepassword) {
	this.srepassword = srepassword;
}




	
	
}
