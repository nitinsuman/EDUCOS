package com.net.educos.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.net.educos.model.Student;

@Transactional
@Repository
public class StudentDaoClass implements StudentDao {

	@Autowired
	private JdbcTemplate jdbctemplate;
	
	@Override
	public void addStudent(Student student) {
	String query ="INSERT INTO student(sid,sname,stream,sgender,saddress,scontact,semail,spassword,srepassword) VALUES(?,?,?,?,?,?,?,?,?)";
    jdbctemplate.update(query,student.getSid(),student.getSname(),student.getStream(),student.getSgender(),student.getSaddress(),student.getScontact(),student.getSemail(),student.getSpassword(),student.getSrepassword());		
	}

	@Override
	public List<Student> getStudents() 
	{
		String query= "SELECT * from student";
		return null;
	}

}
