package com.net.educos.service;

import java.util.List;

import com.net.educos.model.Student;

public class StudentServiceClass implements StudentService {

	@Override
	public void addStudent(Student student) 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Student> getStudents() 
	{
		// TODO Auto-generated method stub
		return null;
	}

}
