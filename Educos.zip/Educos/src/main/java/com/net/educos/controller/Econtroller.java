package com.net.educos.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/educos")
public class Econtroller {

	@RequestMapping(value = { "/login" }, method = RequestMethod.GET)
	public ModelAndView show1() {
		 
		ModelAndView model = new ModelAndView();
		model.setViewName("login");
		return model;
		
	}
	
	@RequestMapping(value = { "/home" }, method = RequestMethod.GET)
	public ModelAndView home() {
		 
		ModelAndView model = new ModelAndView();
		model.setViewName("home");
		return model;
		
	}
	@RequestMapping(value = { "/faculty" }, method = RequestMethod.GET)
	public ModelAndView faculty() {
		 
		ModelAndView model = new ModelAndView();
		model.setViewName("facultyreg");
		return model;
		
	}
	
	@RequestMapping(value = { "/student" }, method = RequestMethod.GET)
	public ModelAndView student() {
		 
		ModelAndView model = new ModelAndView();
		model.setViewName("studentreg");
		return model;
		
	}
}
