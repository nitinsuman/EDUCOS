package com.net.educos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.net.educos.model.Student;

@Transactional
@Repository
public class Scontroller 
{
	@Autowired
	private JdbcTemplate jdbctemplate;



}
